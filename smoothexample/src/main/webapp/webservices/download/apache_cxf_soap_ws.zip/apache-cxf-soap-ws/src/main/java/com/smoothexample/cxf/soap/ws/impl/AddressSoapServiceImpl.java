package com.smoothexample.cxf.soap.ws.impl;

import com.smoothexample.cxf.soap.ws.AddressSoapService;
import com.smoothexample.dto.Address;

public class AddressSoapServiceImpl implements AddressSoapService {

	public Address getAddress() {

		return createAddress();
	}

	private Address createAddress() {
		Address address = new Address();
		address.setStreetAddress("4800 abc Rd");
		address.setCity("abcd");
		address.setState("NJ");
		address.setCountry("US");
		address.setZip("10001");
		address.setAddressOptional("addressOptional");

		return address;
	}

}
