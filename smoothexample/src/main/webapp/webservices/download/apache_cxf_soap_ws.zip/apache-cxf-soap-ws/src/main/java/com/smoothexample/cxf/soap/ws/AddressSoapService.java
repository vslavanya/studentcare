package com.smoothexample.cxf.soap.ws;

import javax.jws.WebService;

import com.smoothexample.dto.Address;



@WebService(endpointInterface = " com.smoothexample.cxf.soap.ws.AddressSoapService", serviceName = "addressSoapService")
public interface AddressSoapService {
	public Address getAddress()
			 throws Exception;
	
}
