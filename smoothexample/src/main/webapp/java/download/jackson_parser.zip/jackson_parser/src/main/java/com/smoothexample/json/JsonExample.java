package com.smoothexample.json;

import java.io.IOException;

import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

public class JsonExample 
{
    public static void main( String[] args ) throws IOException
    {
        Address address = createAddress();
        ObjectMapper objectMapper = getObjectMapper();
        
        System.out.println(" Converting java object to json");
        String  jsonString = objectMapper.writeValueAsString(address);
        System.out.println(jsonString);
        
        System.out.println(" Converting json to java object ");
        
        Address addressFromJson = objectMapper.readValue(jsonString, Address.class);
        System.out.println(addressFromJson.toString());
        
    }
    
    private static Address createAddress() {
		Address address = new Address();
		address.setStreetAddress("4800 abc Rd");
		address.setCity("Edison");
		address.setState("NJ");
		address.setCountry("US");
		address.setZip("10001");
		address.setAddressOptional("apt 1900");

		return address;
	}
    
    
    
    
    private static ObjectMapper getObjectMapper() {
		ObjectMapper objectMapper = new ObjectMapper();
		objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		objectMapper.configure(DeserializationFeature.READ_UNKNOWN_ENUM_VALUES_AS_NULL, true);
		
		objectMapper.setSerializationInclusion(Include.NON_DEFAULT);
		objectMapper.setSerializationInclusion(Include.NON_EMPTY);
		objectMapper.setSerializationInclusion(Include.NON_NULL);
		return objectMapper;
	}
}
