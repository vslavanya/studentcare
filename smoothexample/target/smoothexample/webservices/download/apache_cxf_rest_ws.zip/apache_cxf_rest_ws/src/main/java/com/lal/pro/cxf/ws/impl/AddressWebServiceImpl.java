package com.lal.pro.cxf.ws.impl;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Response;

import com.lal.pro.dto.Address;

public class AddressWebServiceImpl {

	@GET
	@Path("/v1/address")
	@Produces({ "application/xml", "application/json" })
	public Response getAddress() {

		Address addressResponse = createAddress();

		return Response.ok(addressResponse).header("Access-Control-Allow-Origin", "*").build();
	}

	private Address createAddress() {
		Address address = new Address();
		address.setStreetAddress("4800 Edison Rd");
		address.setCity("Edison");
		address.setState("NJ");
		address.setCountry("US");
		address.setZip("10001");
		address.setAddressOptional("Apt #1011");

		return address;
	}

}
