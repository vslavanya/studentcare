package com.smoothexample.pro;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Invocation;
import javax.ws.rs.client.WebTarget;

import com.fasterxml.jackson.jaxrs.json.JacksonJsonProvider;


public class AddressRestServiceClient {
	public static void main(String[] args) {
		Client client = ClientBuilder.newClient();
		client.register(new JacksonJsonProvider());

		WebTarget target = client.target("http://localhost:8080/apache_cxf_rest_ws/system/v1/address");
		Invocation.Builder builder = target.request().accept("application/json");
		Address address = builder.get().readEntity(Address.class);
		System.out.println(address.toString());
	}
}
