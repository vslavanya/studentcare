package com.smoothexample.java8;

import java.util.HashMap;
import java.util.Map;


public class HashMapIteration 
{
    public static void main( String[] args )
    {
        Map<String, String > map = populateMap();
        
        map.forEach((key,value)->{
        	System.out.print("key ="+key);
        	System.out.println("  value ="+value);
        });
    }

	private static Map<String, String> populateMap() {
		 Map<String, String > map = new HashMap<>();
		 map.put("name", "John");
		 map.put("country", "US");
		 map.put("state", "NJ");
		 
		 return map;
	}
}
